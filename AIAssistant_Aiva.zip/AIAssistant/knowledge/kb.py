"""Expert knowledge: material families, print goals and 3D/5D rules.

The numbers are conservative FDM starting points for 0.4 mm nozzles; the
material profile's own temperatures always win (they are not overridden here).
Setting keys are the ones present in this STE Slicer build (fdmprinter.def.json).
"""
import collections

from ..core.errors import ToolError

# family -> description, warping risk, cooling, typical adhesion in 3D, notes
FAMILIES = collections.OrderedDict([
    ("pla", {
        "name": "PLA",
        "about": "жёсткий, простой в печати, низкая термостойкость (~55 °C), хрупкий при ударе",
        "warping": "низкий", "fan": 100, "adhesion_3d": "skirt",
        "notes": ["Лучший выбор для прототипов и макетов."],
    }),
    ("petg", {
        "name": "PETG / CPE",
        "about": "прочный и вязкий, хорошая межслойная адгезия, химстойкий, термостойкость ~70 °C",
        "warping": "низкий", "fan": 40, "adhesion_3d": "brim",
        "notes": ["Сильный обдув снижает межслойную прочность — для нагруженных деталей вентилятор 30–50 %.",
                  "Склонен к нитям: ретракт не отключать."],
    }),
    ("abs", {
        "name": "ABS / ABS-композиты",
        "about": "ударопрочный, термостойкий (~95 °C), заметная усадка",
        "warping": "высокий", "fan": 15, "adhesion_3d": "brim",
        "notes": ["Нужен закрытый/подогреваемый объём, минимальный обдув.",
                  "Для крупных деталей — кайма (brim) 8–10 мм."],
    }),
    ("pa", {
        "name": "Полиамид (PA6, PA12, нейлон)",
        "about": "очень прочный и износостойкий, гибкий, гигроскопичный",
        "warping": "высокий", "fan": 10, "adhesion_3d": "brim",
        "notes": ["Пруток обязательно сушить перед печатью.", "Минимальный обдув, кайма для удержания."],
    }),
    ("pc", {
        "name": "Поликарбонат",
        "about": "очень прочный и термостойкий (~115 °C), высокая усадка",
        "warping": "высокий", "fan": 5, "adhesion_3d": "brim",
        "notes": ["Высокие температуры сопла и стола, без обдува."],
    }),
    ("pp", {
        "name": "Полипропилен",
        "about": "лёгкий, химически стойкий, плохо липнет к столу",
        "warping": "высокий", "fan": 10, "adhesion_3d": "brim",
        "notes": ["Нужна широкая кайма; возможны проблемы адгезии к столу."],
    }),
    ("flex", {
        "name": "Эластомеры (TPU, TPE, SEBS, SBS, TPV)",
        "about": "гибкие, для уплотнений, демпферов, манжет",
        "warping": "низкий", "fan": 50, "adhesion_3d": "skirt",
        "notes": ["Печать медленная (15–25 мм/с), ретракт минимальный.", "Плотность заполнения задаёт жёсткость."],
    }),
    ("pva", {
        "name": "PVA (водорастворимый)",
        "about": "растворимый материал поддержек для второго экструдера",
        "warping": "низкий", "fan": 100, "adhesion_3d": "skirt",
        "notes": ["Используется как материал поддержек (support_extruder_nr на экструдер с PVA)."],
    }),
    ("hips", {
        "name": "HIPS", "about": "лёгкий ударопрочный, растворим в лимонене",
        "warping": "средний", "fan": 20, "adhesion_3d": "brim", "notes": [],
    }),
    ("metal", {
        "name": "Metalcast (металло-/керамонаполненный)",
        "about": "заготовки под отжиг/спекание: сталь 316L, оксидная керамика",
        "warping": "средний", "fan": 0, "adhesion_3d": "brim",
        "notes": ["Для последующего спекания нужно 100 % заполнение и учёт усадки (масштабирование).",
                  "Абразивный материал — закалённое сопло."],
    }),
    ("contifiber", {
        "name": "ContiFiber CPA (непрерывное углеволокно)",
        "about": "армирование непрерывным волокном, только через волоконный экструдер (hfe*-принтеры)",
        "warping": "—", "fan": 0, "adhesion_3d": "—",
        "notes": ["Включается настройкой reinforcement_enabled (доступна, если есть волоконный экструдер).",
                  "Армирование работает в режимах 3D (classic) и 5D (cylindrical_full)."],
    }),
])


def family_of(material_id, material_type=None):
    text = ("%s %s" % (material_id or "", material_type or "")).lower()
    if "contifiber" in text:
        return "contifiber"
    if "metalcast" in text:
        return "metal"
    rules = (("pva", "pva"), ("hips", "hips"), ("petg", "petg"), ("cpe", "petg"),
             ("abspa", "pa"), ("pa6", "pa"), ("pa12", "pa"), ("nylon", "pa"), ("cffpa", "pa"), ("gffpa", "pa"),
             ("tpu", "flex"), ("tpe", "flex"), ("sebs", "flex"), ("sbs", "flex"), ("tpv", "flex"),
             ("asa", "abs"), ("peek", "pc"), ("pom", "pc"), ("pmma", "pc"),
             ("abs", "abs"), ("pc", "pc"), ("pp", "pp"), ("pla", "pla"))
    for token, family in rules:
        if token in text:
            return family
    return "pla"


GOALS = collections.OrderedDict([
    ("strength", {
        "label": "прочность / нагрузка",
        "quality": "draft",
        "settings": collections.OrderedDict([
            ("wall_line_count", (4, "4 периметра — основная несущая часть детали при изгибе и кручении")),
            ("top_bottom_thickness", (1.2, "толстые крышки/днища для жёсткости")),
            ("infill_sparse_density", (40, "40 % заполнения — баланс прочности и массы")),
            ("infill_pattern", ("gyroid", "гироид — изотропная прочность во всех направлениях")),
            ("speed_print", (45, "пониженная скорость улучшает спекание слоёв")),
        ]),
    }),
    ("balanced", {
        "label": "универсально",
        "quality": "fast",
        "settings": collections.OrderedDict([
            ("wall_line_count", (3, "3 периметра — запас прочности без лишнего времени")),
            ("infill_sparse_density", (20, "стандартное заполнение 20 %")),
        ]),
    }),
    ("fast", {
        "label": "быстро / черновик",
        "quality": "verydraft",
        "settings": collections.OrderedDict([
            ("wall_line_count", (2, "2 периметра — минимум для черновика")),
            ("infill_sparse_density", (12, "редкое заполнение экономит время и материал")),
            ("speed_print", (70, "повышенная скорость")),
        ]),
    }),
    ("quality", {
        "label": "качество поверхности / детализация",
        "quality": "normal",
        "settings": collections.OrderedDict([
            ("wall_line_count", (3, "3 периметра для ровной поверхности")),
            ("speed_print", (40, "медленнее — чище поверхность")),
            ("z_seam_type", ("sharpest_corner", "шов прячется в острых углах")),
            ("infill_sparse_density", (20, "заполнение не влияет на внешний вид")),
        ]),
    }),
    ("watertight", {
        "label": "герметичность",
        "quality": "fast",
        "settings": collections.OrderedDict([
            ("wall_line_count", (4, "4 периметра исключают сквозные поры")),
            ("top_bottom_thickness", (1.2, "плотные крышки")),
            ("infill_sparse_density", (30, "опора для крышек")),
            ("z_seam_type", ("back", "шов в одной линии сзади — меньше дефектов по периметру")),
        ]),
    }),
    ("lightweight", {
        "label": "лёгкая деталь",
        "quality": "fast",
        "settings": collections.OrderedDict([
            ("wall_line_count", (2, "2 периметра")),
            ("infill_sparse_density", (10, "минимум заполнения")),
            ("infill_pattern", ("gyroid", "гироид держит форму при малой плотности")),
        ]),
    }),
    ("flexible", {
        "label": "гибкая деталь (эластомер)",
        "quality": "fast",
        "settings": collections.OrderedDict([
            ("speed_print", (20, "эластомеры печатают медленно, иначе пруток сминается")),
            ("retraction_amount", (1.0, "минимальный ретракт для мягкого прутка")),
            ("wall_line_count", (3, "периметры задают упругость стенок")),
            ("infill_sparse_density", (25, "плотность регулирует жёсткость")),
        ]),
    }),
])

QUALITY_LAYERS = collections.OrderedDict([
    ("high", 0.06), ("normal", 0.1), ("fast", 0.15), ("draft", 0.2), ("verydraft", 0.3),
    ("coarse", 0.4), ("extra coarse", 0.6),
])

# Where a setting is allowed to come from. Temperatures and shrinkage stay with the
# material profile; the task preset never writes them. machine_* is refused in set_settings.
MATERIAL_OWNED = (
    "material_print_temperature", "material_print_temperature_layer_0",
    "material_bed_temperature", "material_bed_temperature_layer_0",
    "material_standby_temperature", "build_volume_temperature",
    "material_shrinkage_percentage", "material_shrinkage_percentage_xy",
    "material_shrinkage_percentage_z",
)
_SKIRT_KEYS = ("skirt_line_count", "skirt_gap")
_BRIM_KEYS = ("brim_width",)

# Handbook of 17 plastics. Scale columns (100.3) are a size compensation, not a
# slicer temperature and not material_shrinkage_percentage. The bed value 1150
# from the source table for SAN Ceramo is not a real bed temperature; 115 is used.
PLASTICS = collections.OrderedDict([
    ("pla", {"name": "PLA", "aliases": ("pla",), "density": 1.25, "use_min": -20, "use_max": 40,
              "nozzle_min": 200, "nozzle_max": 220, "bed_min": 50, "bed_max": 70,
              "speed_min": 40, "speed_max": 100, "chamber": None, "hygroscopic": "высокая",
              "shrink_pct": 0.3, "scale_xy": 100.3, "scale_z": 100.2,
              "nozzle_first": 220, "nozzle_rest": 210, "bed_first": 70, "bed_rest": 50}),
    ("petg", {"name": "PETG", "aliases": ("petg", "cpe"), "density": 1.28, "use_min": -40, "use_max": 80,
               "nozzle_min": 220, "nozzle_max": 255, "bed_min": 55, "bed_max": 75,
               "speed_min": 10, "speed_max": 80, "chamber": None, "hygroscopic": "средняя",
               "shrink_pct": 0.5, "scale_xy": 100.5, "scale_z": 100.4,
               "nozzle_first": 255, "nozzle_rest": 230, "bed_first": 75, "bed_rest": 55}),
    ("abs", {"name": "ABS", "aliases": ("abs",), "density": 1.05, "use_min": -40, "use_max": 80,
              "nozzle_min": 240, "nozzle_max": 280, "bed_min": 100, "bed_max": 105,
              "speed_min": 10, "speed_max": 100, "chamber": 60, "hygroscopic": "высокая",
              "shrink_pct": 0.8, "scale_xy": 100.8, "scale_z": 100.7,
              "nozzle_first": 280, "nozzle_rest": 250, "bed_first": 105, "bed_rest": 100}),
    ("hips", {"name": "HIPS", "aliases": ("hips",), "density": 1.04, "use_min": -40, "use_max": 80,
               "nozzle_min": 220, "nozzle_max": 260, "bed_min": 90, "bed_max": 110,
               "speed_min": 40, "speed_max": 80, "chamber": 60, "hygroscopic": "низкая",
               "shrink_pct": 0.4, "scale_xy": 100.4, "scale_z": 100.3,
               "nozzle_first": 260, "nozzle_rest": 230, "bed_first": 110, "bed_rest": 90}),
    ("sbs", {"name": "SBS", "aliases": ("sbs",), "density": 1.01, "use_min": -40, "use_max": 80,
              "nozzle_min": 225, "nozzle_max": 240, "bed_min": 50, "bed_max": 80,
              "speed_min": 40, "speed_max": 100, "chamber": None, "hygroscopic": "низкая",
              "shrink_pct": 0.2, "scale_xy": 100.2, "scale_z": 100.1,
              "nozzle_first": 240, "nozzle_rest": 235, "bed_first": 80, "bed_rest": 50}),
    ("tpu", {"name": "TPU", "aliases": ("tpu", "tpe"), "density": 1.29, "use_min": -35, "use_max": 110,
              "nozzle_min": 200, "nozzle_max": 250, "bed_min": 30, "bed_max": 30,
              "speed_min": 50, "speed_max": 200, "chamber": None, "hygroscopic": "средняя",
              "shrink_pct": 0.4, "scale_xy": 100.4, "scale_z": 100.3,
              "nozzle_first": 250, "nozzle_rest": 210, "bed_first": 30, "bed_rest": 30}),
    ("nylon", {"name": "NYLON", "aliases": ("nylon", "pa6", "pa12", "нейлон"), "density": 1.21,
                "use_min": -30, "use_max": 120, "nozzle_min": 235, "nozzle_max": 260,
                "bed_min": 80, "bed_max": 90, "speed_min": 30, "speed_max": 60, "chamber": None,
                "hygroscopic": "высокая", "shrink_pct": 0.3, "scale_xy": 100.3, "scale_z": 100.2,
                "nozzle_first": 260, "nozzle_rest": 245, "bed_first": 90, "bed_rest": 80}),
    ("asa", {"name": "ASA", "aliases": ("asa",), "density": 1.06, "use_min": -40, "use_max": 90,
              "nozzle_min": 220, "nozzle_max": 270, "bed_min": 90, "bed_max": 110,
              "speed_min": 20, "speed_max": 60, "chamber": 60, "hygroscopic": "низкая",
              "shrink_pct": 1.0, "scale_xy": 101.0, "scale_z": 100.9,
              "nozzle_first": 270, "nozzle_rest": 230, "bed_first": 110, "bed_rest": 90}),
    ("pp", {"name": "PP", "aliases": ("pp",), "density": 0.91, "use_min": -15, "use_max": 110,
             "nozzle_min": 200, "nozzle_max": 240, "bed_min": 80, "bed_max": 100,
             "speed_min": 30, "speed_max": 60, "chamber": 60, "hygroscopic": "низкая",
             "shrink_pct": 1.75, "scale_xy": 101.75, "scale_z": 101.65,
             "nozzle_first": 240, "nozzle_rest": 210, "bed_first": 100, "bed_rest": 80}),
    ("pc", {"name": "PC", "aliases": ("pc", "поликарбонат"), "density": 1.21, "use_min": -140, "use_max": 100,
             "nozzle_min": 240, "nozzle_max": 310, "bed_min": 95, "bed_max": 120,
             "speed_min": 30, "speed_max": 50, "chamber": 75, "hygroscopic": "высокая",
             "shrink_pct": 0.8, "scale_xy": 100.8, "scale_z": 100.7,
             "nozzle_first": 310, "nozzle_rest": 250, "bed_first": 120, "bed_rest": 95}),
    ("pom", {"name": "POM", "aliases": ("pom",), "density": 1.41, "use_min": -40, "use_max": 90,
              "nozzle_min": 230, "nozzle_max": 270, "bed_min": 80, "bed_max": 100,
              "speed_min": 20, "speed_max": 35, "chamber": 65, "hygroscopic": "высокая",
              "shrink_pct": 2.15, "scale_xy": 102.15, "scale_z": 102.05,
              "nozzle_first": 270, "nozzle_rest": 240, "bed_first": 100, "bed_rest": 80}),
    ("pmma", {"name": "PMMA", "aliases": ("pmma",), "density": 1.18, "use_min": -40, "use_max": 90,
               "nozzle_min": 225, "nozzle_max": 245, "bed_min": 90, "bed_max": 110,
               "speed_min": 50, "speed_max": 300, "chamber": 60, "hygroscopic": "средняя",
               "shrink_pct": 0.5, "scale_xy": 100.5, "scale_z": 100.4,
               "nozzle_first": 245, "nozzle_rest": 235, "bed_first": 110, "bed_rest": 90}),
    ("peek", {"name": "PEEK", "aliases": ("peek",), "density": 1.49, "use_min": -65, "use_max": 260,
               "nozzle_min": 380, "nozzle_max": 410, "bed_min": 90, "bed_max": 150,
               "speed_min": 20, "speed_max": 100, "chamber": 115, "hygroscopic": "средняя",
               "shrink_pct": 1.3, "scale_xy": 101.3, "scale_z": 101.2,
               "nozzle_first": 410, "nozzle_rest": 390, "bed_first": 150, "bed_rest": 90}),
    ("san_ceramo", {"name": "SAN Ceramo", "aliases": ("san ceramo", "ceramo"), "density": 1.11,
                     "use_min": -60, "use_max": 100, "nozzle_min": 230, "nozzle_max": 250,
                     "bed_min": 90, "bed_max": 115, "speed_min": 50, "speed_max": 150, "chamber": None,
                     "hygroscopic": "низкая", "shrink_pct": 0.6, "scale_xy": 100.6, "scale_z": 100.5,
                     "nozzle_first": 250, "nozzle_rest": 240, "bed_first": 115, "bed_rest": 90}),
    ("san_aertex", {"name": "SAN Aertex", "aliases": ("san aertex", "aertex"), "density": 0.82,
                     "use_min": -60, "use_max": 120, "nozzle_min": 230, "nozzle_max": 250,
                     "bed_min": 80, "bed_max": 105, "speed_min": 15, "speed_max": 80, "chamber": None,
                     "hygroscopic": "низкая", "shrink_pct": 0.75, "scale_xy": 100.75, "scale_z": 100.65,
                     "nozzle_first": 250, "nozzle_rest": 240, "bed_first": 105, "bed_rest": 80}),
    ("wax", {"name": "WAX", "aliases": ("wax", "воск"), "density": 0.94, "use_min": -40, "use_max": 45,
              "nozzle_min": 100, "nozzle_max": 130, "bed_min": 0, "bed_max": 0,
              "speed_min": 25, "speed_max": 65, "chamber": None, "hygroscopic": "низкая",
              "shrink_pct": 0.7, "scale_xy": 100.7, "scale_z": 100.6,
              "nozzle_first": 130, "nozzle_rest": 110, "bed_first": 0, "bed_rest": 0}),
    ("pva", {"name": "PVA", "aliases": ("pva",), "density": 1.23, "use_min": -80, "use_max": 130,
              "nozzle_min": 180, "nozzle_max": 210, "bed_min": 60, "bed_max": 80,
              "speed_min": 30, "speed_max": 60, "chamber": None, "hygroscopic": "высокая",
              "shrink_pct": 0.3, "scale_xy": 100.3, "scale_z": 100.2,
              "nozzle_first": 210, "nozzle_rest": 190, "bed_first": 80, "bed_rest": 60}),
])

# Task types. `visual` is how to recognise the type on a user photo: the earlier
# plugin named example files, but no image files were shipped with it.
PRINT_CASES = collections.OrderedDict([
    ("assembly", {
        "label": "сборочная единица",
        "priorities": ["скорость", "точность"],
        "visual": "несколько деталей одного комплекта, отверстия под крепёж, стыкуемые плоскости",
        "adhesion": None,
        "settings": collections.OrderedDict([
            ("wall_line_count", (3, "3 периметра: точность стыков без лишнего времени")),
            ("infill_sparse_density", (25, "25 % — жёсткость узла сборки")),
            ("infill_pattern", ("gyroid", "гироид держит размеры в разных направлениях")),
        ]),
    }),
    ("print_in_place", {
        "label": "механизм print-in-place",
        "priorities": ["точность", "экономия"],
        "visual": "шарнир, петля или зазор: деталь должна двигаться сразу после печати",
        "adhesion": None,
        "settings": collections.OrderedDict([
            ("wall_line_count", (3, "3 периметра держат зазор шарнира")),
            ("infill_sparse_density", (15, "15 % — меньше материала, который может затечь в зазор")),
            ("infill_pattern", ("lines", "прямолинейное заполнение меньше затекает в зазор")),
            ("support_type", ("buildplate", "если поддержки нужны — только от стола, чтобы не запечатать зазор")),
        ]),
    }),
    ("complex", {
        "label": "сложная геометрия",
        "priorities": ["точность", "прочность"],
        "visual": "много свесов, тонкие рёбра, решётка или органическая форма",
        "adhesion": None,
        "settings": collections.OrderedDict([
            ("wall_line_count", (3, "3 периметра сохраняют тонкие элементы")),
            ("infill_sparse_density", (20, "20 % опоры под сложную форму")),
            ("infill_pattern", ("gyroid", "гироид поддерживает своды")),
            ("support_enable", (True, "сложная геометрия обычно требует поддержек")),
            ("support_type", ("everywhere", "поддержки ставятся по свесам, не только от стола")),
        ]),
    }),
    ("postprocess", {
        "label": "под обработку",
        "priorities": ["прочность", "экономия"],
        "visual": "заготовка простой формы с припуском под шлифовку или сверление",
        "adhesion": None,
        "settings": collections.OrderedDict([
            ("wall_line_count", (2, "2 периметра: припуск всё равно снимается обработкой")),
            ("infill_sparse_density", (20, "20 % — прочность без лишнего пластика")),
            ("infill_pattern", ("lines", "прямолинейное заполнение быстрее печатается")),
        ]),
    }),
    ("small_contact", {
        "label": "малая площадь контакта со столом",
        "priorities": ["адгезия"],
        "visual": "узкая ножка или маленькая пятка, высокая деталь на малом основании",
        "adhesion": "skirt",
        "settings": collections.OrderedDict([
            ("adhesion_type", ("skirt", "широкая юбка с нулевым зазором держит маленькую пятку")),
            ("skirt_gap", (0, "нулевой зазор: юбка касается детали")),
            ("skirt_line_count", (12, "около 5 мм при линии 0.4 мм, внутри диапазона 3–6 мм")),
        ]),
    }),
])

MODE_RULES = [
    "3D (classic) — универсальный режим: плоские, коробчатые, корпусные детали, кронштейны с плоским основанием, всё, что не является телом вращения.",
    "5D (cylindrical_full) — деталь поворачивается вокруг вертикальной оси в центре стола, слои ложатся цилиндрическими оболочками: тела вращения (втулки, ролики, трубы, валы, манжеты, крыльчатки), детали под внутреннее давление/радиальную нагрузку; меньше поддержек, выше прочность поперёк оси.",
    "В 5D модель ставится по центру стола (X=0, Y=0), ось вращения детали — вертикально; ядро вокруг оси (диаметр cylindrical_mode_base_diameter, по умолчанию 6 мм) печатается в 3D, остальное — цилиндрическими слоями.",
    "В 5D адгезия по умолчанию — raft (cylindrical_raft_type=solid): не переопределять без причины.",
    "5D доступен только на пятиосевых принтерах (machine_five_axis=true); на трёхосевых — только 3D.",
    "5D Spiral, Discrete, Spherical — экспериментальные режимы; использовать только по прямому запросу пользователя.",
]


def handbook_entry(material_id, material_type=None):
    text = ("%s %s" % (material_id or "", material_type or "")).lower()
    best_key, best_row, best_len = None, None, 0
    for key, row in PLASTICS.items():
        for alias in row["aliases"]:
            if alias in text and len(alias) > best_len:
                best_key, best_row, best_len = key, row, len(alias)
    return best_key, best_row


def _handbook_public(row):
    chamber = "не требуется" if row["chamber"] is None else "%d °C" % row["chamber"]
    return {
        "name": row["name"],
        "density_g_cm3": row["density"],
        "service_c": [row["use_min"], row["use_max"]],
        "nozzle_c": [row["nozzle_min"], row["nozzle_max"]],
        "nozzle_first_c": row["nozzle_first"],
        "nozzle_other_c": row["nozzle_rest"],
        "bed_c": [row["bed_min"], row["bed_max"]],
        "bed_first_c": row["bed_first"],
        "bed_other_c": row["bed_rest"],
        "speed_mm_s": [row["speed_min"], row["speed_max"]],
        "chamber": chamber,
        "hygroscopic": row["hygroscopic"],
        "shrink_pct": row["shrink_pct"],
        "scale_xy_pct": row["scale_xy"],
        "scale_z_pct": row["scale_z"],
        "use": "Справочник. В слайсер пишите температуры профиля материала, не эти числа.",
    }


def _drop(settings, reasons, keys):
    for key in keys:
        settings.pop(key, None)
        reasons.pop(key, None)


def _apply_adhesion(settings, reasons, notes, family, case, five_d):
    """Skirt and brim are two ways to help the first layer. Keep exactly one."""
    if five_d:
        _drop(settings, reasons, ("adhesion_type",) + _SKIRT_KEYS + _BRIM_KEYS)
        notes.append("Режим 5D: адгезия — raft режима. Кайма и юбка не включаются.")
        return
    material_choice = family["adhesion_3d"] if family["adhesion_3d"] in ("skirt", "brim") else None
    case_choice = case["adhesion"] if case else None
    if case_choice and material_choice and case_choice != material_choice:
        notes.append("Кайма и юбка взаимоисключающие. Для типа задачи «%s» остаётся %s, "
                     "вариант материала (%s) не добавляется." % (case["label"], case_choice, material_choice))
    chosen = case_choice or material_choice
    if chosen == "brim":
        _drop(settings, reasons, _SKIRT_KEYS)
        settings["adhesion_type"] = "brim"
        reasons["adhesion_type"] = "кайма удерживает углы (коробление: %s). Юбка при этом не включается." % family["warping"]
    elif chosen == "skirt":
        _drop(settings, reasons, _BRIM_KEYS)
        if "adhesion_type" not in settings:
            settings["adhesion_type"] = "skirt"
            reasons["adhesion_type"] = "юбка достаточна — материал почти не коробится"
    else:
        _drop(settings, reasons, ("adhesion_type",) + _SKIRT_KEYS + _BRIM_KEYS)


def _setting_source(key):
    if key in MATERIAL_OWNED or key in ("cool_fan_speed", "cool_fan_enabled"):
        return "material"
    if key in ("adhesion_type",) + _SKIRT_KEYS + _BRIM_KEYS:
        return "adhesion"
    return "task"


def prepare_user_settings(values):
    """Drop the adhesion helper that the chosen type does not use.

    Returns a new dict and notes for the agent. Material-owned keys are left in
    place but called out, so an explicit user request still applies.
    """
    cleaned = dict(values)
    notes = []
    adhesion = cleaned.get("adhesion_type")
    has_brim = any(key in cleaned for key in _BRIM_KEYS)
    has_skirt = any(key in cleaned for key in _SKIRT_KEYS)
    if adhesion in ("brim", "raft") and has_skirt:
        _drop(cleaned, {}, _SKIRT_KEYS)
        notes.append("Кайма и юбка вместе не включаются. Для adhesion_type=%s юбка убрана." % adhesion)
    elif adhesion in ("skirt", "none") and has_brim:
        _drop(cleaned, {}, _BRIM_KEYS)
        notes.append("Кайма и юбка вместе не включаются. Для adhesion_type=%s кайма убрана." % adhesion)
    elif adhesion is None and has_brim and has_skirt:
        _drop(cleaned, {}, _SKIRT_KEYS)
        cleaned["adhesion_type"] = "brim"
        notes.append("Кайма и юбка заданы вместе. Оставлена кайма, adhesion_type=brim.")
    for key in cleaned:
        if key in MATERIAL_OWNED:
            notes.append("%s берётся из профиля материала. Меняйте его только если пользователь прямо попросил." % key)
    return cleaned, notes


def recommend(goal="balanced", material_id=None, material_type=None, printing_mode="classic",
              no_supports=False, temperatures=None, print_case=None):
    goal_key = (goal or "balanced").strip().lower()
    if goal_key not in GOALS:
        raise ToolError("Неизвестная цель '%s'." % goal, hint="Доступны: " + ", ".join(GOALS.keys()))
    case_key = (print_case or "").strip().lower() or None
    if case_key is not None and case_key not in PRINT_CASES:
        raise ToolError("Неизвестный тип задачи '%s'." % print_case,
                        hint="Доступны: " + ", ".join(PRINT_CASES.keys()))
    preset = GOALS[goal_key]
    case = PRINT_CASES[case_key] if case_key else None
    family_key = family_of(material_id, material_type)
    family = FAMILIES[family_key]
    five_d = printing_mode not in ("classic", "3D", "3d")

    settings = collections.OrderedDict()
    reasons = collections.OrderedDict()
    for key, (value, why) in preset["settings"].items():
        settings[key] = value
        reasons[key] = why
    if case:
        for key, (value, why) in case["settings"].items():
            settings[key] = value
            reasons[key] = "%s (тип задачи «%s», приоритет: %s)" % (why, case["label"], ", ".join(case["priorities"]))

    fan = family["fan"]
    if family_key in ("petg",) and goal_key == "strength":
        fan = 30
    settings["cool_fan_speed"] = fan
    reasons["cool_fan_speed"] = "обдув из материала %s: %d %%" % (family["name"], fan)
    if fan == 0:
        settings["cool_fan_enabled"] = False
        reasons["cool_fan_enabled"] = "материал печатается без обдува"

    if family_key == "flex":
        for key in ("speed_print", "retraction_amount"):
            settings[key], reasons[key] = GOALS["flexible"]["settings"][key]
    if family_key == "metal":
        settings["infill_sparse_density"] = 100
        reasons["infill_sparse_density"] = "для спекания деталь должна быть сплошной"

    warnings = list(family["notes"])
    _apply_adhesion(settings, reasons, warnings, family, case, five_d)

    if no_supports:
        settings["support_enable"] = False
        reasons["support_enable"] = "пользователь просит без поддержек — компенсируем ориентацией" + (" и 5D" if five_d else "")
    if family_key == "contifiber":
        settings["reinforcement_enabled"] = True
        reasons["reinforcement_enabled"] = "включить армирование непрерывным волокном"

    _hkey, handbook_row = handbook_entry(material_id, material_type)
    sources = collections.OrderedDict((key, _setting_source(key)) for key in settings)
    result = {
        "goal": goal_key,
        "goal_label": preset["label"],
        "material_family": family["name"],
        "material_about": family["about"],
        "printing_mode": printing_mode,
        "recommended_quality": preset["quality"],
        "recommended_layer_height": QUALITY_LAYERS.get(preset["quality"]),
        "settings": settings,
        "reasons": reasons,
        "sources": sources,
        "material_temperatures": temperatures or {},
        "notes": warnings,
        "how_to_apply": "Профиль: set_quality_profile(quality_type=recommended_quality); настройки: set_settings(settings). "
                        "В settings только ключи задачи, адгезии и обдува. Температуры и усадку из справочника туда не копируйте.",
    }
    if case:
        result["print_case"] = case_key
        result["print_case_label"] = case["label"]
        result["priorities"] = case["priorities"]
    if handbook_row:
        result["material_handbook"] = _handbook_public(handbook_row)
    return result


def prompt_digest():
    lines = ["Материалы (семейства):"]
    for family in FAMILIES.values():
        lines.append("- %s: %s; коробление: %s." % (family["name"], family["about"], family["warping"]))
    lines.append("Линейки Stereotech: Proto (PLA, PVA — прототипы), Enduse (ABS, PA6, PC, PETG, PP, SBS, TPU — "
                 "конечные изделия), Fiberpart (композиты со стекло-/углеволокном: G — стекло, C — углерод, число — %), "
                 "Sealant (эластомеры для уплотнений), Metalcast (под спекание), ContiFiber (непрерывное волокно).")
    lines.append("Профили качества (quality_type → слой): " + ", ".join(
        "%s → %.2f мм" % (k, v) for k, v in QUALITY_LAYERS.items()))
    lines.append("Цели для get_recommendations: " + ", ".join("%s (%s)" % (k, g["label"]) for k, g in GOALS.items()))
    lines.append("Откуда брать параметр:")
    lines.append("- Из материала, в set_settings не писать: температуры сопла и стола, термокамера, усадка. Их даёт профиль материала. Справочник ниже — для объяснения.")
    lines.append("- Из типа задачи и цели: периметры, заполнение, шаблон, скорость, поддержки.")
    lines.append("- Адгезия — ровно один вариант: none, skirt, brim или raft. Кайма и юбка вместе не включаются. В 5D адгезию не переопределять.")
    lines.append("- Не трогать machine_*: это геометрия принтера.")
    lines.append("Типы задач (print_case). Фото пользователя сопоставляй с приметами:")
    for key, case in PRINT_CASES.items():
        lines.append("- %s (%s); приоритет: %s; на фото: %s." % (key, case["label"], ", ".join(case["priorities"]), case["visual"]))
    lines.append("Справочник пластиков (температуры — ориентир, в слайсер их не копировать):")
    for row in PLASTICS.values():
        chamber = "камера не нужна" if row["chamber"] is None else "камера %d °C" % row["chamber"]
        lines.append("- %s: сопло %d–%d °C (первый слой %d), стол %d–%d °C, усадка %s %%, гигроскопичность %s, масштаб XY %s %%, %s." % (
            row["name"], row["nozzle_min"], row["nozzle_max"], row["nozzle_first"],
            row["bed_min"], row["bed_max"], row["shrink_pct"], row["hygroscopic"], row["scale_xy"], chamber))
    lines.append("Правила выбора режима:")
    lines.extend("- " + rule for rule in MODE_RULES)
    return "\n".join(lines)
